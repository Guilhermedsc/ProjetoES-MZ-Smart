export const constants ={
    DatabaseSource: "DATABASE_SOURCE",
    UsersController: "users",
    UsersRepository: "USERS_REPOSITORY"
}