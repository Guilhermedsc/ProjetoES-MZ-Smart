import { IsMongoId, IsString, Length, IsNumber} from "class-validator"
import { ObjectId } from "typeorm"

export class CreateDevicesDTO {
    @IsMongoId()
    user_id: ObjectId

    @IsString()
    @Length(3, 100)
    model: string

    @IsString()
    @Length(0, 3000)
    description: string

    @IsNumber()
    value: number

    @IsString()
    solution_description: string
}
